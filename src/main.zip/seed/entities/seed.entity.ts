export class Seed {}
