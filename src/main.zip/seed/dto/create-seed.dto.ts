export class CreateSeedDto {}
