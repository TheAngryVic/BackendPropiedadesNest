import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
// import { PropiedadImage } from './entities/propiedade-images.entity';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class FilesService {


  /**
   *
   */
  constructor(
  
  ) {
    
    
  }

 
}
